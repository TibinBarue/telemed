import React from "react";

function page() {
  return <div>onboard page</div>;
}

export default page;
