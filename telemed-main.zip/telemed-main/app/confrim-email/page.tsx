import React from "react";

function page() {
  return <div>confirm email page</div>;
}

export default page;
